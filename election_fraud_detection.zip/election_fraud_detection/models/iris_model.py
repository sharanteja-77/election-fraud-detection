"""
models/iris_model.py
TensorFlow/Keras CNN model for iris feature extraction and identity matching.

Architecture
------------
- Siamese-style embedding network: input → CNN → 128-D L2-normalised vector
- At recognition time, cosine similarity between the probe embedding and all
  stored voter embeddings is computed; the best match above MATCH_THRESHOLD
  is accepted.

Training
--------
Call `IrisModel.train(X, y)` where X is (N, 64, 64, 1) and y is integer labels.
A simple classification head is added for training then discarded; only the
embedding backbone is kept.
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, callbacks
from typing import Optional, Tuple

# ── Constants ──────────────────────────────────────────────────────────────
INPUT_SHAPE     = (64, 64, 1)
EMBEDDING_DIM   = 128
MATCH_THRESHOLD = 0.75        # Cosine similarity must exceed this to accept

MODEL_DIR  = os.path.join(os.path.dirname(__file__))
MODEL_PATH = os.path.join(MODEL_DIR, "iris_model.h5")


# ── Model Definition ────────────────────────────────────────────────────────

def build_embedding_model() -> tf.keras.Model:
    """
    CNN backbone that maps a (64, 64, 1) iris image to a 128-D unit vector.
    """
    inp = layers.Input(shape=INPUT_SHAPE, name="iris_input")

    # Block 1
    x = layers.Conv2D(32, (3, 3), padding="same", activation="relu")(inp)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)

    # Block 2
    x = layers.Conv2D(64, (3, 3), padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)

    # Block 3
    x = layers.Conv2D(128, (3, 3), padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)

    # Block 4
    x = layers.Conv2D(256, (3, 3), padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.GlobalAveragePooling2D()(x)

    # Dense projection
    x = layers.Dense(EMBEDDING_DIM)(x)
    x = layers.Lambda(
        lambda t: tf.math.l2_normalize(t, axis=1),
        name="l2_norm"
    )(x)

    return tf.keras.Model(inputs=inp, outputs=x, name="IrisEmbedder")


def build_classifier(num_classes: int) -> tf.keras.Model:
    """Wrap the embedding model with a softmax head for supervised training."""
    base  = build_embedding_model()
    inp   = base.input
    embed = base.output
    out   = layers.Dense(num_classes, activation="softmax", name="class_head")(embed)
    return tf.keras.Model(inputs=inp, outputs=out, name="IrisClassifier")


# ── IrisModel class ─────────────────────────────────────────────────────────

class IrisModel:
    """
    High-level interface for training, saving, loading, and inference.
    """

    def __init__(self):
        self.embedder: Optional[tf.keras.Model] = None
        self._load_or_init()

    # ── Initialisation ──────────────────────────────────────────────────────

    def _load_or_init(self):
        if os.path.exists(MODEL_PATH):
            try:
                self.embedder = tf.keras.models.load_model(MODEL_PATH)
                print(f"[Model] Loaded saved model from {MODEL_PATH}")
                return
            except Exception as e:
                print(f"[Model] Could not load saved model ({e}), rebuilding.")
        self.embedder = build_embedding_model()
        print("[Model] Initialised new embedding model (untrained).")

    # ── Training ────────────────────────────────────────────────────────────

    def train(self,
              X: np.ndarray,
              y: np.ndarray,
              epochs: int = 30,
              batch_size: int = 32,
              val_split: float = 0.15) -> dict:
        """
        Train the model on iris images.

        Parameters
        ----------
        X : (N, 64, 64, 1) float32 array, values in [0, 1]
        y : (N,) integer class labels (one per voter)

        Returns
        -------
        Training history dict
        """
        num_classes = len(np.unique(y))
        classifier  = build_classifier(num_classes)

        classifier.compile(
            optimizer=optimizers.Adam(learning_rate=1e-3),
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"],
        )

        cb_list = [
            callbacks.EarlyStopping(monitor="val_loss", patience=5,
                                    restore_best_weights=True),
            callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                         patience=3, min_lr=1e-6),
            callbacks.ModelCheckpoint(MODEL_PATH, save_best_only=True,
                                       monitor="val_accuracy"),
        ]

        history = classifier.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=val_split,
            callbacks=cb_list,
            verbose=1,
        )

        # Keep only the embedding backbone
        self.embedder = tf.keras.Model(
            inputs=classifier.input,
            outputs=classifier.get_layer("l2_norm").output,
            name="IrisEmbedder",
        )
        self.embedder.save(MODEL_PATH)
        print(f"[Model] Embedding model saved to {MODEL_PATH}")
        return history.history

    # ── Inference ───────────────────────────────────────────────────────────

    def extract_features(self, iris_image: np.ndarray) -> np.ndarray:
        """
        Extract a 128-D embedding from a preprocessed iris image.

        Parameters
        ----------
        iris_image : (64, 64, 1) float32 array

        Returns
        -------
        numpy array of shape (128,)
        """
        if self.embedder is None:
            raise RuntimeError("Embedder not initialised.")
        inp = iris_image[np.newaxis, ...]              # (1, 64, 64, 1)
        return self.embedder.predict(inp, verbose=0)[0]

    def match(self,
              probe_features: np.ndarray,
              stored_records: list[dict]) -> Tuple[Optional[str], float]:
        """
        Compare probe embedding against all stored voter embeddings.

        Parameters
        ----------
        probe_features : (128,) embedding of the probe iris
        stored_records : list of dicts with keys 'voter_id' and 'iris_features'

        Returns
        -------
        (best_voter_id, cosine_similarity)  — voter_id is None if no match found
        """
        if not stored_records:
            return None, 0.0

        probe = probe_features / (np.linalg.norm(probe_features) + 1e-8)

        best_id    = None
        best_score = -1.0

        for record in stored_records:
            stored_vec = np.array(record["iris_features"], dtype=np.float32)
            stored_vec = stored_vec / (np.linalg.norm(stored_vec) + 1e-8)
            score      = float(np.dot(probe, stored_vec))
            if score > best_score:
                best_score = score
                best_id    = record["voter_id"]

        if best_score >= MATCH_THRESHOLD:
            return best_id, best_score
        return None, best_score

    def save(self, path: str = MODEL_PATH):
        if self.embedder:
            self.embedder.save(path)
            print(f"[Model] Saved to {path}")

    # ── Data augmentation helper ─────────────────────────────────────────────

    @staticmethod
    def augment_batch(X: np.ndarray) -> np.ndarray:
        """
        Simple augmentation: random flip, brightness jitter, and noise.
        Useful for training on small datasets.
        """
        augmented = []
        for img in X:
            if np.random.rand() > 0.5:
                img = np.fliplr(img)
            img = img + np.random.normal(0, 0.02, img.shape)
            img = np.clip(img, 0, 1)
            brightness = np.random.uniform(0.85, 1.15)
            img = np.clip(img * brightness, 0, 1)
            augmented.append(img)
        return np.array(augmented, dtype=np.float32)


# ── Singleton accessor ───────────────────────────────────────────────────────

_model_instance: Optional[IrisModel] = None


def get_model() -> IrisModel:
    """Return (or create) the global IrisModel singleton."""
    global _model_instance
    if _model_instance is None:
        _model_instance = IrisModel()
    return _model_instance
